This LightWave object reader is based on the lw mesh reader by Janne L�f.
It can be obtained from http://www.student.oulu.fi/~jlof/free/.

ReaderWriterLWO.cpp is the OSG code which adapts the library into a osg plugin.

Copyright (C) Ulrich Hertlein <u.hertlein@web.de>
