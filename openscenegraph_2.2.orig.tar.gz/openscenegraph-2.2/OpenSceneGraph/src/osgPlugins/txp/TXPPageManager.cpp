#include "TXPPageManager.h"
using namespace txp;
        
TXPPageManager::TXPPageManager():
trpgPageManager()
{
}

TXPPageManager::~TXPPageManager()
{
}
